#!/usr/bin/env python3
# (C) 2017 OpenEye Scientific Software Inc. All rights reserved.
#
# TERMS FOR USE OF SAMPLE CODE The software below ("Sample Code") is
# provided to current licensees or subscribers of OpenEye products or
# SaaS offerings (each a "Customer").
# Customer is hereby permitted to use, copy, and modify the Sample Code,
# subject to these terms. OpenEye claims no rights to Customer's
# modifications. Modification of Sample Code is at Customer's sole and
# exclusive risk. Sample Code may require Customer to have a then
# current license or subscription to the applicable OpenEye offering.
# THE SAMPLE CODE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED.  OPENEYE DISCLAIMS ALL WARRANTIES, INCLUDING, BUT
# NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. In no event shall OpenEye be
# liable for any damages or liability in connection with the Sample Code
# or its use.

#############################################################################
# Plots ROC curve
#############################################################################

import sys
import os
from operator import itemgetter
import matplotlib.pyplot as plt
from sklearn.metrics import auc



#Note:
#Comment dòng 61 và 142,143 để thấy lỗi hệ thống

# def main(argv=[__name__]):



def load_actives(fname):

    actives = []
    for line in open(fname, 'r').readlines():
        id = line.strip()
        actives.append(id)

    return actives


def load_scores(fname):

    sfile = open(fname, 'r')
    label = sfile.readline()
    label = label.strip()

    scores = []
    for line in sfile.readlines():
        id, score = line.strip().split()
        scores.append((id, float(score)))

    return label, scores


def get_rates(actives, scores):
    """
    :type actives: list[sting]
    :type scores: list[tuple(string, float)]
    :rtype: tuple(list[float], list[float])
    """

    tpr = [0.0]  # true positive rate
    fpr = [0.0]  # false positive rate
    nractives = len(actives)
    nrdecoys = len(scores) - len(actives)
    # cnt=0
    foundactives = 0.0
    founddecoys = 0.0
    for idx, (id, score) in enumerate(scores): #sorted score 
        if id in actives:
            foundactives += 1.0
            # cnt+=1;print(cnt,id)
        else:
            founddecoys += 1.0

        tpr.append(foundactives / float(nractives))
        fpr.append(founddecoys / float(nrdecoys))

    return tpr, fpr


def setup_ROC_curve_plot(plt):
    """
    :type plt: matplotlib.pyplot
    """

    plt.xlabel("FPR", fontsize=14)
    plt.ylabel("TPR", fontsize=14)
    plt.title("ROC Curve", fontsize=14)


def save_ROC_curve_plot(plt, filename, randomline=True):
    """
    :type plt: matplotlib.pyplot
    :type fname: string
    :type randomline: boolean
    """

    if randomline:
        x = [0.0, 1.0]
        plt.plot(x, x, linestyle='dashed', color='red', linewidth=2, label='random')

    # plt.xlim(0.0, 1.0)
    # plt.ylim(0.0, 1.0)
    plt.legend(fontsize=10, loc='best')
    plt.tight_layout()
    plt.savefig(filename)


def depict_ROC_curve(actives, scores, label, color, filename, randomline=True):
    """
    :type actives: list[sting]
    :type scores: list[tuple(string, float)]
    :type color: string (hex color code)
    :type fname: string
    :type randomline: boolean
    """

    plt.figure(figsize=(4, 4), dpi=80)

    setup_ROC_curve_plot(plt)
    add_ROC_curve(plt, actives, scores, color, label)
    save_ROC_curve_plot(plt, filename, randomline)


def add_ROC_curve(plt, actives, scores, color, label):
    """
    :type plt: matplotlib.pyplot
    :type actives: list[sting]
    :type scores: list[tuple(string, float)]
    :type color: string (hex color code)
    :type label: string
    """

    tpr, fpr = get_rates(actives, scores)
    roc_auc = auc(fpr, tpr)

    roc_label = '{} (AUC={:.3f})'.format(label, roc_auc)
    plt.plot(fpr, tpr, color=color, linewidth=2, label=roc_label)


def is_supported_image_type(ext):
    fig = plt.figure()
    return (ext[1:] in fig.canvas.get_supported_filetypes())


# if __name__ == "__main__":
#     sys.exit(main(sys.argv))

def main():
    # if len(sys.argv) != 4:
    #     print("Usage: <actives> <scores> <image>")
    #     return 1

    afname = '/home/u/2018/draw-ROC/actives.txt'  #sys.argv[1]
    sfnameB = '/home/u/2018/draw-ROC/scores_bad.txt' #sys.argv[2]
    sfnameG = '/home/u/2018/draw-ROC/scores_good.txt' #sys.argv[2]
    sfnameN = '/home/u/2018/draw-ROC/scores_normal.txt' #sys.argv[2]
    ofname = '/home/u/2018/draw-ROC/roc_bad.svg' #sys.argv[3]

    sName=[sfnameB,sfnameG,sfnameN]
    ofname_3 = '/home/u/2018/draw-ROC/roc_3.svg' #sys.argv[3]
    

    f, ext = os.path.splitext(ofname)
    if not is_supported_image_type(ext):
        print("Format \"%s\" is not supported!" % ext)
        return 1

    # read id of actives

    actives = load_actives(afname)
    print("Loaded %d actives from %s" % (len(actives), afname))

    # read molecule id - score pairs
    plt.figure(figsize=(6, 6), dpi=80)
    setup_ROC_curve_plot(plt)
    colors=['r','g','b']
    plt.grid(True)
    for k,sfname in enumerate(sName):
        label, scores = load_scores(sfname)
        print("Loaded %d %s scores from %s" % (len(scores), label, sfname))

        # sort scores by ascending order
        sortedscores=scores # Chuyển comment 2 dòng lệnh này để thấy sự khác biệt.
        sortedscores = sorted(scores, key=itemgetter(1))
        
        print("Plotting ROC Curve ...")
        color = colors[k] #"#008000"  # dark green
        # depict_ROC_curve(actives, sortedscores, label, color, ofname)

    
        add_ROC_curve(plt, actives, sortedscores, color, label)

    save_ROC_curve_plot(plt, ofname_3, randomline=True)

    return 0
main()